import { StyleSheet, Text, View } from "react-native";
import React from "react";

const login = () => {
  return (
    <View>
      <Text>login</Text>
    </View>
  );
};

export default login;

const styles = StyleSheet.create({});
